var AlbumModel = Backbone.Model.extend({
});

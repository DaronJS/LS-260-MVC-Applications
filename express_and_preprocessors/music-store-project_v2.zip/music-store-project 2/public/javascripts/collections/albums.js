var AlbumsCollection = Backbone.Collection.extend({
  model: AlbumModel,
});
